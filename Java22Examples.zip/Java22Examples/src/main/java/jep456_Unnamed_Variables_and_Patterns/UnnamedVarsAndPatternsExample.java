package jep456_Unnamed_Variables_and_Patterns;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class UnnamedVarsAndPatternsExample
{
	public static void main(final String[] args)
	{
		unnamedVariable("userInput: E605");

		unnamedPatternVariableAndPattern();
	}

	private static void unnamedPatternVariableAndPattern()
	{
		enum Color { RED, GREEN, BLUE, BLACK, WHITE }
		record Point(int x, int y) { }
		record ColoredPoint(Point point, Color color) { }

		var cp = new ColoredPoint(new Point(1234, 567), Color.BLUE);

		if (cp instanceof ColoredPoint(Point(int x,
											 var _), // $\mbox{\bfseries UNNAMED PATTERN VARIABLE}$
									   _)) // $\mbox{\bfseries UNNAMED PATTERN}$
		{
			System.out.println("x: " + x);
		}
	}

	private static void unnamedVariable(final String userInput)
	{
		try
		{
			processInput(Integer.parseInt(userInput));
		}
		catch (NumberFormatException _) // $\mbox{\bfseries UNNAMED VARIABLE}$
		{
			System.out.println("Expected number, but was: '" + userInput + "'");
		}
	}

	private static void processInput(int i)
	{
		System.out.println("Input " + i);
	}
}
