package jep464_Scoped_Values;

import java.time.ZonedDateTime;
import java.util.List;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class ScopedValuesExample {

    public static final ScopedValue<User> LOGGED_IN_USER = ScopedValue.newInstance();
    public static final ScopedValue<ZonedDateTime> REQUEST_TIME = ScopedValue.newInstance();

    public static final Controller controller = createController(new Service());

    private static Controller createController(final Service service) {
        return new Controller(service);
    }

    public static void main(String[] args) throws Exception {

        // Simuliere Requests
        for (String name : List.of("ATTACKER", "ADMIN"))
        {
            var user = new User(name, name.toLowerCase());
            ScopedValue.where(LOGGED_IN_USER, user).
                    where(REQUEST_TIME, ZonedDateTime.now()).
                    run(controller::consumingMethod);

            // short cut
            ScopedValue.runWhere(LOGGED_IN_USER, user,
                    controller::consumingMethod);

            String answer = ScopedValue.where(LOGGED_IN_USER, user).call(() -> controller.process());
            System.out.println(answer);
        }

        // Außerhalb des Scopes ist die Variable "unbound"
        System.out.println("Outside bounded scope");
        System.out.println("isBound(): " + LOGGED_IN_USER.isBound());
        //System.out.println("get(): " + LOGGED_IN_USER.get());
    }
}
