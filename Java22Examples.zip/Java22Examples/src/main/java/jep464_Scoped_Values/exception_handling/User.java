package jep464_Scoped_Values.exception_handling;

record User(String name, String nickName) {}