package jep464_Scoped_Values.exception_handling;

import java.io.IOException;

public class Java22Example
{
    public static void main(String[] args) {

        var user = new User("Tim", "Bötz");

        // Java 22:
        try
        {
            var result = ScopedValue.callWhere(ScopedValuesExample.LOGGED_IN_USER,
                                               user, Java22Example::performCalculation);
            System.out.println("Calculated result: " + result);
        }
        catch (Exception e)
        {
            if (e instanceof IOException ioe)
                handleIoException(ioe);

            throw new RuntimeException(e);
        }

        // Java 22: Unhandled exception: java.lang.Exception
        /*
        try
        {
            String result = ScopedValue.callWhere(ScopedValuesExample.LOGGED_IN_USER,
                    user, Java22xample::performCalculation);
            System.out.println("Calculated result: " + result);
        } catch (IOException e) {
            handleIoException(ioe);
        }
        */

        // Java 22: Unhandled exception: java.lang.Exception
        try
        {
            String result = ScopedValue.callWhere(ScopedValuesExample.LOGGED_IN_USER,
                                               user,
                                               Java22Example::performCalculationUnchecked);
            System.out.println("Calculated result: " + result);
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }

    static String performCalculation() throws IOException
    {
        if (ScopedValuesExample.LOGGED_IN_USER.isBound())
            return ScopedValuesExample.LOGGED_IN_USER.get().name();

        return "FALLBACK FIRST";
    }

    static String performCalculationUnchecked() throws IllegalStateException
    {
        if (ScopedValuesExample.LOGGED_IN_USER.isBound())
            return ScopedValuesExample.LOGGED_IN_USER.get().nickName();

        return "FALLBACK SECOND";
    }

    private static void handleIoException(IOException ioe) {
    }
}
