package jep464_Scoped_Values.exception_handling;

import java.time.ZonedDateTime;

public class ScopedValuesExample
{
    public static final ScopedValue<User> LOGGED_IN_USER = 
                                          ScopedValue.newInstance();
    public static final ScopedValue<ZonedDateTime> REQUEST_TIME =
                                                   ScopedValue.newInstance();


    // ...
}