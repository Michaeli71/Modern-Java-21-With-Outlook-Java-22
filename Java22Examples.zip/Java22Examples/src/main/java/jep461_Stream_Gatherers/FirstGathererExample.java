package jep461_Stream_Gatherers;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Gatherer;
import java.util.stream.Gatherers;
import java.util.stream.Stream;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class FirstGathererExample {
    public static void main(final String[] args) {

        // WISH
        /*
        var result = Stream.of("Tim", "Tom", "Jim", "Mike").
                            distinctBy(String::length).      // Hypothetical
                            toList();
        */

        var result = Stream.of("Tim", "Tom", "Jim", "Mike")
                .map(DistinctByLength::new)
                .distinct()
                .map(DistinctByLength::str)
                .toList();

        System.out.println("result: " + result);
    }

    record DistinctByLength(String str) {

        @Override public boolean equals(Object obj) {
            return obj instanceof DistinctByLength(String other)
                    && str.length() == other.length();
        }

        @Override public int hashCode() {
            return str == null ? 0 : Integer.hashCode(str.length());
        }
    }
}
