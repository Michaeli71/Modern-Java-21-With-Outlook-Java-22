package jep460_Vector_Api;

import jdk.incubator.vector.IntVector;

import java.util.Arrays;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class FirstVectorExample {
    public static void main(final String[] args) {

        int[] a = {1, 2, 3, 4, 5, 6, 7, 8};
        int[] b = {1, 2, 3, 4, 5, 6, 7, 8};

        var result1 = performScalarAddition(a, b);
        System.out.println("result using scalar calulation: " + Arrays.toString(result1));

        var result2 = performVectorAddition(a, b);
        System.out.println("result using Vector API: " + Arrays.toString(result2));
    }

        private static int[] performScalarAddition(int[] a, int[] b)
        {
            int[] c = new int[a.length];

            for (int i = 0; i < a.length; i++)
            {
                c[i] = a[i] + b[i];
            }

            return c;
        }

    private static int[] performVectorAddition(int[] a, int[] b)
    {
        int[] c = new int[a.length];

        IntVector vectorA = IntVector.fromArray(IntVector.SPECIES_256, a, 0);
        IntVector vectorB = IntVector.fromArray(IntVector.SPECIES_256, b, 0);

        IntVector vectorC = vectorA.add(vectorB); // var vectorC = vectorA.mul(vectorB);
        vectorC.intoArray(c, 0);

        return c;
    }
}
