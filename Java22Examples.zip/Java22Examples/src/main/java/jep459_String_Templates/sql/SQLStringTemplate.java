package jep459_String_Templates.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import static jep459_String_Templates.sql.H2Helper.*;
import static jep459_String_Templates.sql.SqlHelper.extractPersons;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class SQLStringTemplate {

    public static void main(final String[] args) {
        try (Connection conn = createInitialConnection()) {
            dropTable(conn);
            createTable(conn);

            insertPersonUsingSimpleStringTemplate(conn, 0, "Hans", "Muster", "hans@muster.com");
            insertPersonUsingQueryBuilder(conn, 1, "Susi", "Muster", "hans@muster.com");

            var personen = getPersonByLastNameUsingSimpleStringTemplate(conn, "Muster");
            System.out.println("Personen using SimpleStringTemplate: " + personen);

            var personen2 = getPersonByLastNameUsingQueryBuilder(conn, "Muster");
            System.out.println("Personen using QueryBuilder        : " + personen2);
        } catch (SQLException | ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    private static void insertPersonUsingSimpleStringTemplate(Connection conn, Integer id, String firstName, String lastName, String email) throws SQLException {
        try (Statement stmt = conn.createStatement()) {
            String sql = STR."insert into person values ('\{id}', '\{firstName}', '\{lastName}', '\{email}')";
            stmt.executeUpdate(sql);
        }
    }

    private static void insertPersonUsingQueryBuilder(Connection conn, Integer id, String firstName, String lastName, String email) throws SQLException {
        QueryBuilder QUERY = new QueryBuilder(conn);
        try (PreparedStatement _ = QUERY."insert into person values (\{id}, \{firstName}, \{lastName}, \{email})") {
        }
    }

    private static List<Person> getPersonByLastNameUsingSimpleStringTemplate(Connection conn, String lastName) throws SQLException {
        try (Statement stmt = conn.createStatement()) {
            String sql = STR."select id, first_name, last_name, email from person p where p.last_name='\{lastName}'";
            return extractPersons(stmt, sql);
        }
    }

    private static List<Person> getPersonByLastNameUsingQueryBuilder(Connection conn, String lastName) throws SQLException {
        QueryBuilder QUERY = new QueryBuilder(conn);
        try (PreparedStatement preparedStatement = QUERY."select id, first_name, last_name, email from person p where p.last_name = \{lastName}") {
            return extractPersons(preparedStatement);
        }
    }

    record QueryBuilder(Connection conn) implements StringTemplate.Processor<PreparedStatement, SQLException> {

        public PreparedStatement process(StringTemplate stringTemplate) throws SQLException {
            // Schritt 1: StringTemplate => PreparedStatement with placeholders
            var query = String.join("?", stringTemplate.fragments());

            // Schritt 2: PreparedStatement erzeugen
            var preparedStatement = conn.prepareStatement(query);

            // Schritt 3: Parameter besetzen
            int index = 1;
            for (Object value : stringTemplate.values()) {
                switch (value) {
                    case Integer i -> preparedStatement.setInt(index, i);
                    case Float f -> preparedStatement.setFloat(index, f);
                    case Double d -> preparedStatement.setDouble(index, d);
                    case Boolean b -> preparedStatement.setBoolean(index, b);
                    default -> preparedStatement.setString(index, "" + value);
                }
                index++;
            }
            System.out.println(preparedStatement);
            return preparedStatement;
        }
    }
}
