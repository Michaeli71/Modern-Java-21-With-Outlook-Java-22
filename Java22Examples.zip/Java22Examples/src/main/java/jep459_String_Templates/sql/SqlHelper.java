package jep459_String_Templates.sql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class SqlHelper {

    public static List<Person> extractPersons(Statement stmt, String sql) throws SQLException {
        List<Person> persons = new ArrayList<>();
        try (ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                persons.add(extractPerson(rs));
            }
        }
        return persons;
    }

    public static List<Person> extractPersons(PreparedStatement preparedStatement) throws SQLException {
        List<Person> persons = new ArrayList<>();
        try (ResultSet rs = preparedStatement.executeQuery()) {
            while (rs.next()) {
                persons.add(extractPerson(rs));
            }
        }
        return persons;
    }

    private static Person extractPerson(ResultSet rs) throws SQLException {
        int id = rs.getInt("id");
        String first = rs.getString("first_name");
        String last = rs.getString("last_name");
        String email = rs.getString("email");
        return new Person(id, first, last, email);
    }
}
