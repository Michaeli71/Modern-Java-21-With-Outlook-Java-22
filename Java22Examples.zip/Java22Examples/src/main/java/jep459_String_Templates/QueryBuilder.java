package jep459_String_Templates;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
record QueryBuilder(Connection conn)
  implements StringTemplate.Processor<PreparedStatement, SQLException>
{
    public PreparedStatement process(StringTemplate stringTemplate) throws SQLException 
    {
        // Schritt 1: StringTemplate => PreparedStatement placeholders 
        var query = String.join("?", stringTemplate.fragments());

        // Schritt 2: PreparedStatement erzeugen
        var preparedStatement = conn.prepareStatement(query);

        // Schritt 3: Parameter besetzen
        int index = 1;
        for (Object value : stringTemplate.values()) 
        {
            switch (value) 
            {
                case Integer i -> preparedStatement.setInt(index, i);
                case Float f -> preparedStatement.setFloat(index, f);
                case Double d -> preparedStatement.setDouble(index, d);
                case Boolean b -> preparedStatement.setBoolean(index, b);
                default -> preparedStatement.setString(index, "" + value);
            }
            index++;
        }
        return preparedStatement;
    }
}