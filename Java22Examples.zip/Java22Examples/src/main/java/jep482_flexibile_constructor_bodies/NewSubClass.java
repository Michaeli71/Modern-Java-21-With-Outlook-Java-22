package jep482_flexibile_constructor_bodies;

public class NewSubClass extends BaseClass {

    private final String subClassInfo;

    public NewSubClass(int baseField, String subClassInfo)
    {
        super(baseField);
        this.subClassInfo = subClassInfo;
    }

    protected void logValues()
    {
        super.logValues();
        System.out.println("subClassInfo: " + subClassInfo);
    }

    public static void main(final String[] args)
    {
        new NewSubClass(42, "SURPRISE");
    }
}
