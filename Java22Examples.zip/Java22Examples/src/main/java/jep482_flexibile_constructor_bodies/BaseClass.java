package jep482_flexibile_constructor_bodies;

public class BaseClass
{
    private final int baseField;

    public BaseClass(int baseField)
    {
        this.baseField = baseField;

        logValues();
    }

    protected void logValues()
    {
        System.out.println("baseField: " + baseField);
    }
}
