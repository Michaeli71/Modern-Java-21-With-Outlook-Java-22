package jep454_Foreign_Function;

import java.lang.foreign.*;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.util.List;

import static java.lang.foreign.Linker.nativeLinker;
import static java.lang.foreign.ValueLayout.*;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class CallQSortWithFFMExample
{
    public static void main(final String[] args) throws Throwable
    {
        // Schritt 1 : SymbolLookUp + Method Handle ermitteln
        var qsortMethodHandle = getQSortMethodHandle();

        // Schritt 2:
        var arena = Arena.ofAuto();
        var callbackPtr = createCompareCallBack(arena);

        // Schritt 3: Eingabedaten
        final byte[] values = {9, 4, 8, 6, 11, 13, 17, 19, 7, 5, 3, 2};
        var valuesMemorySegment = arena.allocateFrom(JAVA_BYTE, values);

        // Schritt 4: Aufruf von "qsort" aus der C-Bibliothek
        qsortMethodHandle.invokeWithArguments(valuesMemorySegment, values.length, 1, callbackPtr);

        // Schritt 5: Rückkonvertierung aus dem sortierten C-Speicher
        // in eine Java-Liste
        final List<Integer> sortedValues = convertToList(valuesMemorySegment);
        System.out.println("sortedValues: " + sortedValues);
    }

    private static MethodHandle getQSortMethodHandle() throws Exception
    {
        var cStdLib = nativeLinker().defaultLookup();
        var qsortSymbol = cStdLib.find("qsort").orElseThrow();

        // qsort erhält eine Adresse auf die Daten, zwei int sowie eine
        // Adresse auf eine Vergleichsfunktion für die Elemente
        var qsortFunc = FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT,
                                                  ADDRESS);

        return nativeLinker().downcallHandle(qsortSymbol, qsortFunc);
    }

    private static MemorySegment createCompareCallBack(final Arena arena)
                   throws NoSuchMethodException, IllegalAccessException
    {
        var callbackJavaSig = MethodType.methodType(int.class, MemorySegment.class,
                                                               MemorySegment.class);
        var callbackJava = MethodHandles.lookup().bind(new MyDescComparator(),
                                                "compare", callbackJavaSig);

        // Method signature of compare function in C lang
        var callbackCSig = FunctionDescriptor.of(ValueLayout.JAVA_INT,
                                                 ValueLayout.ADDRESS, ValueLayout.ADDRESS);

        // Java method als call back stub bereitstellen
        return nativeLinker().upcallStub(callbackJava, callbackCSig, arena);
    }

    private static List<Integer> convertToList(final MemorySegment valuesMemorySegment)
    {
        return valuesMemorySegment.elements(JAVA_BYTE).
                map(elm -> Integer.valueOf(elm.get(JAVA_BYTE, 0))).
                toList();
    }

    private static class MyDescComparator
    {
        private int compare(final MemorySegment left, final MemorySegment right)
        {
            final var leftByte = extractValue(left);
            final var rightByte = extractValue(right);

            return Byte.compare(rightByte, leftByte);
        }

        private static byte extractValue(final MemorySegment memorySegment)
        {
            return MemorySegment.ofAddress(memorySegment.address()).
                                 reinterpret(JAVA_BYTE.byteSize()).
                                 get(JAVA_BYTE, 0);
        }
    }
}
