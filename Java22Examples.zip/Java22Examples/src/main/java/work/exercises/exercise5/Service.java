package work.exercises.exercise5;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class Service {

    public void consumingMethod(final User user)
    {
        System.out.println("Consumer: " + user);
    }

    public String process(final User loggedInUser)
    {
        if (loggedInUser.name().startsWith("ADMIN"))
            return "ACCESS GRANTED!";
        else
            return "Top Secret Processing ... no access to value granted";
    }
}
