package work.exercises.exercise5;

import java.time.ZonedDateTime;
import java.util.List;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class ScopedValuesExample {

    // TO BE USED
    public static final ScopedValue<User> LOGGED_IN_USER = ScopedValue.newInstance();
    public static final ScopedValue<ZonedDateTime> REQUEST_TIME = ScopedValue.newInstance();

    public static final Controller controller = createController(new Service());

    private static Controller createController(final Service service) {
        return new Controller(service);
    }

    public static void main(final String[] args) throws Exception
    {
        // Simuliere Requests
        for (String name : List.of("ATTACKER", "ADMIN"))
        {
            var user = new User(name, name.toLowerCase());
            controller.consumingMethod(user, ZonedDateTime.now());
            // TODO: Umwandlung mit ScopedValue consumingMethod() ohne Parameter

            // no time passed
            controller.consumingMethod(user, null);
            // TODO: Umwandlung mit ScopedValue consumingMethod() ohne Parameter

            String answer = controller.process(user, ZonedDateTime.now());
            // TODO: Umwandlung mit ScopedValue process() ohne Parameter
            System.out.println(answer);

            // no time passed
            String answer2 = controller.process(user, null);
            // TODO: Umwandlung mit ScopedValue process() ohne Parameter
            System.out.println(answer2);
        }
    }
}
