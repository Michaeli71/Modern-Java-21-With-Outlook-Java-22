package work.exercises.exercise2;

import java.util.Arrays;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
class PlainByteMsg {

    private final byte[] payload;

    public PlainByteMsg(final byte[] payload) {
        this.payload = payload;
    }

    @Override
    public String toString() {
        return "PlainByteMsg{" +
                "payload=" + Arrays.toString(payload) +
                '}';
    }
}