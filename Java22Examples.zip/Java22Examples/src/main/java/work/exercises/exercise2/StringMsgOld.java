package work.exercises.exercise2;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class StringMsgOld extends PlainByteMsg {
    public StringMsgOld(final String payload) {
        super(convertToByteArray(payload));
    }

    // Auxiliary method: Null-Prüfung, Verarbeitung und Konvertierung gemixt
    private static byte[] convertToByteArray(final String payload) {
        if (payload == null)
            throw new IllegalArgumentException("payload should not be null");

        String transformedPayload = heavyStringTransformation(payload);
        return switch (transformedPayload) {
            case "AA" -> new byte[]{1, 2, 3, 4};
            case "BBBB" -> new byte[]{7, 2, 7, 1};
            default -> transformedPayload.getBytes();
        };
    }

    private static String heavyStringTransformation(String input) {
        return input.repeat(2);
    }


    public static void main(String[] args) {
        System.out.println(new StringMsgOld("A"));
        System.out.println(new StringMsgOld("BB"));
        System.out.println(new StringMsgOld("HELLO SOPHIE"));
        System.out.println(new StringMsgOld(null));
    }
}