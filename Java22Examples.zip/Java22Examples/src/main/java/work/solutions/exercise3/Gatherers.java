package work.solutions.exercise3;

import java.util.stream.Stream;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class Gatherers {
    public static void main(String[] args) {
        var crossMult = Stream.of(1, 2, 3, 4, 5, 6, 7).
                gather(java.util.stream.Gatherers.fold(() -> 1L,
                        (result, number) -> result * number)).
                findFirst();
        System.out.println("crossMult: " + crossMult);
        // crossMult ==> Optional[5040]

        var values = Stream.of(1, 2, 3, 10, 20, 30, 100, 200, 300);
        System.out.println(values.gather(java.util.stream.Gatherers.windowFixed(3)).toList());
        // [[1, 2, 3], [10, 20, 30], [100, 200, 300]]
    }
}
