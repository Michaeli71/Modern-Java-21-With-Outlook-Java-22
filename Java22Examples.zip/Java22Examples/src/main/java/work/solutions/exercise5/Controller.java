package work.solutions.exercise5;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class Controller {

    private final Service service;

    public Controller(final Service service) {
        this.service = service;
    }

    public void consumingMethod()
    {
        if (ScopedValuesExample.REQUEST_TIME.isBound())
            System.out.println("consumingMethod() -- request Time: " +
                               ScopedValuesExample.REQUEST_TIME.get());

        service.consumingMethod();
    }

    public String process()
    {
        if (ScopedValuesExample.REQUEST_TIME.isBound())
            System.out.println("process() -- request Time: " +
                               ScopedValuesExample.REQUEST_TIME.get());

        return service.process();
    }
}
