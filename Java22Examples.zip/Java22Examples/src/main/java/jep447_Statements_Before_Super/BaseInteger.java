package jep447_Statements_Before_Super;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
class BaseInteger
{
    private final long value;

    BaseInteger(final long value) {
        this.value = value;
    }

    public long getValue() {
        return value;
    }

    public static void main(final String[] args)
    {
        new BaseInteger(4711);
    }
}