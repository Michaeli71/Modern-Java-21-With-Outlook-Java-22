package api;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class StringBufferRepeat
{
    public static void main(final String[] args)
    {
        var buffer = new StringBuffer().repeat("BLA", 3);
        System.out.println(buffer);

        System.out.println(new StringBuffer().repeat("BLA", 3));

        buffer = new StringBuffer();
        buffer = buffer.repeat("MOIN", 2);
        System.out.println(buffer);

        var sb = new StringBuffer();
        sb.repeat('*', 10);
        System.out.println(sb);
    }
}
