package ch02_syntax_java_12_17.ch02_03_records;

import java.util.Objects;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public record RecordEqualsExample(String name, int age)
{
    // ACHTUNG: DO NOT DO IT AT HOME :-)

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RecordEqualsExample other = (RecordEqualsExample) obj;
        return Objects.equals(name, other.name);
    }

    public static void main(String[] args)
    {
        var p1 = new RecordEqualsExample("Peter", 72);
        var p2 = new RecordEqualsExample("Peter", 27);

        System.out.println(p1.equals(p2));
    }
}
