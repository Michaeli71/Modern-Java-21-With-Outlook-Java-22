package ch02_syntax_java_12_17.ch02_03_records.extension;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
record MyPoint(int x, int y)
{
    public MyPoint(final String values)
    {
        this(Integer.parseInt(values.split(",")[0].strip()),
             Integer.parseInt(values.split(",")[1].strip()));
    }
}