package ch02_syntax_java_12_17.ch02_03_records.extension;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public record RgbColorV1(int red, int green, int blue)
{
    public String asHex()
    {
        return String.format("#%02X%02X%02X", red, green, blue);
    }
}