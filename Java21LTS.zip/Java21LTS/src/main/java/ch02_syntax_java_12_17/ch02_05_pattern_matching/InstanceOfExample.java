package ch02_syntax_java_12_17.ch02_05_pattern_matching;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class InstanceOfExample
{
    public static void main(final String[] args)
    {
        Object obj2 = "Hallo Java 17";

        if (obj2 instanceof String)
        {
            String str2 = (String) obj2;
            if (str2.length() > 5 && str2.startsWith("Ha"))
            {
                System.out.println("Länge: " + str2.length());
            }
        }

        if (obj2 instanceof String str2 && str2.length() > 5 && str2.startsWith("Ha"))
        {
            System.out.println("Länge: " + str2.length());
        }
    }
}
