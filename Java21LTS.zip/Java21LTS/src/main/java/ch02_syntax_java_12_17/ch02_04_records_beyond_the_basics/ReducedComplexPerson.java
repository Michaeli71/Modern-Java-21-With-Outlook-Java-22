package ch02_syntax_java_12_17.ch02_04_records_beyond_the_basics;

import java.time.LocalDate;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
record Address(String addressStreet, String addressNumber, String city)
{
}

record BodyInfo(int height, int weight)
{
}

record PersonDTO(String firstname, String surname, LocalDate birthday)
{
}

public record ReducedComplexPerson(PersonDTO person, BodyInfo bodyInfo, Address address)
{
    public static void main(String[] args)
    {
        var john = new PersonDTO("“John", "Smith", LocalDate.of(2010, 6,  21));
        var bodyInfo = new BodyInfo(170, 90);
        var address = new Address("ullstrasse", "16a", "Berlin"); 

        var rcp = new ReducedComplexPerson(john, bodyInfo, address);
        System.out.println(rcp);
    }
}