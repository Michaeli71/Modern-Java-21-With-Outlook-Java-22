package ch02_syntax_java_12_17.ch02_09_pattern_matching_preview;

import java.time.DayOfWeek;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 17 / 18 / 19" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22 by Michael Inden
 */
public class SwitchPreviewExample
{
    public static void main(String[] args)
    {

        DayOfWeek day = DayOfWeek.WEDNESDAY;
        int numLetters = switch (day)
        {
            case MONDAY, FRIDAY, SUNDAY -> 6;
            case TUESDAY -> 7;
            case THURSDAY, SATURDAY -> 8;
            case WEDNESDAY -> 9;
            // default -> throw new IllegalStateException("Invalid day: " + day);
        };

        System.out.println(numLetters);

        processData("V1");
        processData("V2");
        processData(71);

        typeBasedActionWithSwitch("Java21LTS");
        typeBasedActionWithSwitch(new int[] { 7, 2, 7, 1 });

        switchSupportingNull("Python");

        // not working in Eclipse?!
        switchSupportingNull(null);
    }

    static String typeBasedActionWithSwitch(Object obj)
    {
        return switch (obj)
        {
            case List things -> "A List of things with size: " + things.size();
            case Map map -> "A Map containing these keys: " + map.keySet();
            case String str -> "This is a string with content: " + str;
            case int[] ints -> "Processing int array" + Arrays.toString(ints);
            default -> "This is something else.";
        };
    }

    static void switchSpecialNullSupport(String str)
    {
        if (str == null)
        {
            System.out.println("special handling for null");
            return;
        }
        switch (str)
        {
            case "Java", "Python" -> System.out.println("cool language");
            default -> System.out.println("everything else");
        }
    }

    static void switchSupportingNull(String str)
    {
        switch (str)
        {
            case null -> System.out.println("null is allowed in preview");
            case "Java", "Python" -> System.out.println("cool language");
            default -> System.out.println("everything else");
        }
    }

    static void processData(Object obj)
    {
        switch (obj)
        {
            case String str when
                            str.startsWith("V1") -> System.out.println("Processing V1");
            case String str when
                            str.startsWith("V2") -> System.out.println("Processing V2");
            case Integer i when
                            i > 10 && i < 100 -> System.out.println("Processing ints");
            default -> throw new IllegalArgumentException("invalid input");
        }
    }
}
