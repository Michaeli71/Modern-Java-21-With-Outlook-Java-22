package ch02_syntax_java_12_17.ch02_02_switch_expressions;

import java.time.DayOfWeek;

import static java.time.DayOfWeek.*;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class YieldExample
{
    public static void main(final String[] args)
    {
        var day = SUNDAY;

        int numOfLetters = switch (day)
        {
            case MONDAY, FRIDAY, SUNDAY ->
            {
                if (day == DayOfWeek.SUNDAY)
                    System.out.println("SUNDAY is FUN DAY");
                yield 6;
            }
            case TUESDAY -> 7;
            case THURSDAY, SATURDAY -> 8;
            case WEDNESDAY -> 9;
        };
    }
}
