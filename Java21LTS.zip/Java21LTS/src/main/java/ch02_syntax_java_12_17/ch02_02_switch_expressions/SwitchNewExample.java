package ch02_syntax_java_12_17.ch02_02_switch_expressions;

import java.time.DayOfWeek;
import java.time.Month;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class SwitchNewExample
{
    public static void main(String[] args)
    {
        DayOfWeek day = DayOfWeek.WEDNESDAY;

        int numLetters = switch (day)
        {
            case MONDAY, FRIDAY, SUNDAY -> 6;
            case TUESDAY -> 7;
            case THURSDAY, SATURDAY -> 8;
            case WEDNESDAY -> 9;
            // default -> throw new IllegalStateException("Invalid day: " + day);
        };

        System.out.println(numLetters);
    }

    static String monthToName(final Month month)
    {
        return switch (month)
        {
            case JANUARY -> "January";
            default -> "N/A"; // hier KEIN Fall Through
            case FEBRUARY -> "February";
            case MARCH -> "March";
        };
    }
}
