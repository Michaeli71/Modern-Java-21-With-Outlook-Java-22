package ch02_syntax_java_12_17.ch02_02_switch_expressions;

import java.time.DayOfWeek;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class SwitchOldExample
{
    public static void main(final String[] args)
    {
        DayOfWeek day = DayOfWeek.FRIDAY;

        int numOfLetters;
        switch (day)
        {
            case MONDAY:
            case FRIDAY:
            case SUNDAY:
                numOfLetters = 6;
                break;
            case TUESDAY:
                numOfLetters = 7;
                break;
            case THURSDAY:
            case SATURDAY:
                numOfLetters = 8;
                break;
            case WEDNESDAY:
                numOfLetters = 9;
                break;
            default:
                numOfLetters = -1;
        }
        System.out.println(numOfLetters);

        pitfall();
    }

    private static void pitfall()
    {
        DayOfWeek day = DayOfWeek.WEDNESDAY;

        int numOfLetters;
        switch (day)
        {
            case THURSDAY:
            case SATURDAY:
                numOfLetters = 8;
                break;
        }
        //System.out.println(numOfLetters);
    }

    private static void solution()
    {
        DayOfWeek day = DayOfWeek.WEDNESDAY;

        int numOfLetters = switch (day)
        {
            case THURSDAY, SATURDAY -> 8;
            default -> throw new IllegalArgumentException("Unexpected value: " + day);
        };
        System.out.println(numOfLetters);
    }
}
