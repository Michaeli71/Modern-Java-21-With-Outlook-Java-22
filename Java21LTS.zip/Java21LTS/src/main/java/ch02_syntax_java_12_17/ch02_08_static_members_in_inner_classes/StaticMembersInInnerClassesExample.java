package ch02_syntax_java_12_17.ch02_08_static_members_in_inner_classes;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 17 / 18 / 19" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22 by Michael Inden
 */
public class StaticMembersInInnerClassesExample
{
    class InnerClass
    {
        static final String STATIC_MESSAGE = "allowed since Java 16";

        static String staticMethod()
        {
            return STATIC_MESSAGE;
        }
    }

    public static void main(final String[] args)
    {
        System.out.println("Static fields ... " + InnerClass.STATIC_MESSAGE);
        System.out.println("Static methods ... " + InnerClass.staticMethod());
    }
}