package ch02_syntax_java_12_17.ch02_07_local_enums_and_interfaces;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class LocalEnumAndInterfaceExample
{
    public static void main(final String[] args)
    {
        enum LocalEnumState
        {
            BAD, GOOD, UNKNOWN
        }

        interface Evaluationable
        {
            LocalEnumState evaluate(String info);
        }

        class AlwaysBad implements Evaluationable
        {
            @Override
            public LocalEnumState evaluate(String info)
            {
                return LocalEnumState.BAD;
            }
        }

        var actionResult = new AlwaysBad().evaluate("DOES NOT MATTER");
        System.out.println(actionResult);
    }
}