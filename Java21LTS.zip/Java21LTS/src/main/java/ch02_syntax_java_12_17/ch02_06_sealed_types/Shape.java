package ch02_syntax_java_12_17.ch02_06_sealed_types;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021-2025 by Michael Inden
 */
abstract sealed class Shape
{
    final class Circle extends Shape
    {
    }

    final class Rectangle extends Shape
    {
    }

    final class Square extends Shape
    {
    }

    public static void main(String[] args)
    {

    }
}
