package ch02_syntax_java_12_17.ch02_06_sealed_types;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021-2025 by Michael Inden
 */
public class SealedTypesExamples
{
    sealed interface MathOp permits BaseOp, Add, Sub // <= erlaubte Subtypen
    {
        int calc(int x, int y);
    }

    // Mit non-sealed kann man innerhalb der Vererbungshierarchie Basisklassen
    // bereitstellen
    non-sealed class BaseOp implements MathOp // <= Basisklasse
                    // nicht versiegeln
    {
        @Override
        public int calc(int x, int y)
        {
            return 0;
        }
    }

    final class Add implements MathOp
    {
        @Override
        public int calc(int x, int y)
        {
            return x + y;
        }
    }

    final class Sub implements MathOp
    {
        @Override
        public int calc(int x, int y)
        {
            return x - y;
        }
    }

    // Ableitung aus Basisklasse muss final sein
    final class Mult extends BaseOp
    {
        @Override
        public int calc(int x, int y)
        {
            return x * y;
        }
    }

    final class Div extends BaseOp
    {
        @Override
        public int calc(int x, int y)
        {
            return x / y;
        }
    }
}