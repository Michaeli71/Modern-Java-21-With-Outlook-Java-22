package ch02_syntax_java_12_17.ch02_06_sealed_types;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
// Mit non-sealed kann man Basisklassen innerhalb der Vererbungshierarchie
// bereitstellen
non-sealed abstract class BaseOp implements MathOp
{
    @Override
    public int calc(int x, int y)
    {
        return 0;
    }
}

// Ableitung von non-sealed muss nicht final sein
class Mult extends BaseOp
{
    @Override
    public int calc(int x, int y)
    {
        return x * y;
    }
}

class Div extends BaseOp
{
    @Override
    public int calc(int x, int y)
    {
        return x / y;
    }
}
