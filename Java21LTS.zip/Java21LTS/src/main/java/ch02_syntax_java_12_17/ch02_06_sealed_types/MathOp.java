package ch02_syntax_java_12_17.ch02_06_sealed_types;

sealed interface MathOp permits BaseOp, Add, Sub
{
    int calc(int x, int y);
}
