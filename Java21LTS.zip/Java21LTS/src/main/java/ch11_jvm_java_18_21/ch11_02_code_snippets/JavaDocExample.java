package ch11_jvm_java_18_21.ch11_02_code_snippets;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class JavaDocExample
{
    /**
     * The following code shows how to use {@code Optional.isPresent} and
     * {@code Optional.get} in combination
     *
     * {@snippet :
     * if (optValue.isPresent()) // @highlight substring="isPresent"
     * {
     *     System.out.println("value: " + optValue.get()); // @highlight substring="get"
     * }}
     */
    public static void newJavaDocExample(String[] args)
    {
        // 
        //
        //
        //
    }
}