package ch09_syntax_java_18_21.ch09_03_pattern_matching;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class SwitchSpecialCasesExample
{
    interface Shape {}

    record Rectangle() implements Shape {}
    record Triangle()  implements Shape { int calculateArea() { return 7271; } }

    static void testTriangleAndString(Object obj)
    {
        switch (obj)
        {
            case Triangle t when t.calculateArea() > 7000 ->
                    System.out.println("Large triangle");
            case String str when str.startsWith("INFO") ->
                    System.out.println("just an info");
            default ->
                    System.out.println("Something else: " + obj);
        }
    }

    static void testTriangleAndString2(Object obj)
    {
        switch (obj)
        {
            case Triangle t when t.calculateArea() > 7000 ->
                System.out.println("Large triangle");
            case String str when str.startsWith("INFO") && str.contains("SPECIAL") ->
                System.out.println("a very special info");
            case String str when str.startsWith("INFO") ->
                System.out.println("just an info");
            // not detected ...
            case String str when str.startsWith("INFO") && str.contains("SPECIAL") ->
                System.out.println("a very special info");
           default -> System.out.println("Something else: " + obj);
        }
    }

    public static void main(String[] args)
    {
        testTriangleAndString(new Triangle());
        testTriangleAndString("INFO: switch and when");
        testTriangleAndString("INFO: switch and SPECIAL");
        testTriangleAndString2("INFO: switch and SPECIAL");
        testTriangleAndString("Michael");
    }
}
