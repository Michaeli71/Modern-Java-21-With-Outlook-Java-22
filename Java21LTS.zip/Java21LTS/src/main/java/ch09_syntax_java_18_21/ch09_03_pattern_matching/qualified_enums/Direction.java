package ch09_syntax_java_18_21.ch09_03_pattern_matching.qualified_enums;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
sealed interface Direction permits CompassDirection, PlayerDirection
{
}

enum CompassDirection implements Direction
{NORTH, SOUTH, EAST, WEST}

enum PlayerDirection implements Direction
{UP, DOWN, LEFT, RIGHT}