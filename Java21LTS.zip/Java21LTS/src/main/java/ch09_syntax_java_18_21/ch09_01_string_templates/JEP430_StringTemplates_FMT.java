package ch09_syntax_java_18_21.ch09_01_string_templates;

import static java.util.FormatProcessor.FMT;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class JEP430_StringTemplates_FMT
{
    public static void main(final String[] args)
    {
        int x = 47;
        int y = 11;
        String calculation1 = FMT."%6d\{x} + %6d\{y} = %6d\{x + y}";
        System.out.println("fmt calculation 1: " + calculation1);

        float base = 3.0f;
        float addon = 0.1415f;
        String calculation2 = FMT."%2.4f\{base} + %2.4f\{addon}" +
                        FMT." = %2.4f\{base + addon}";
        System.out.println("fmt calculation 2: " + calculation2);

        String calculation3 = FMT."Math.PI * 1.000 = %4.6f\{Math.PI * 1000}";
        System.out.println("fmt calculation 3: " + calculation3);
    }
}
