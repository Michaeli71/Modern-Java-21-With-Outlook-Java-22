package ch09_syntax_java_18_21.ch09_02_record_patterns;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class JEP440_RecordPatternsExample
{
    record Point(int x, int y)
    {
    }

    static void printCoordinateInfo(Object obj)
    {
        if (obj instanceof Point point)
        {
            int x = point.x();
            int y = point.y();

            System.out.println("x: %d, y: %d, sum: %d".formatted(x, y, x + y));
        }
    }

    static void printCoordinateInfoRecordPatterns(Object obj)
    {
        if (obj instanceof Point(int x, int y))
        {
            System.out.println("x: %d, y: %d, sum: %d".formatted(x, y, x + y));
        }
    }

    public static void main(final String[] args)
    {
        printCoordinateInfo(new Point(72, 71));
        printCoordinateInfoRecordPatterns(new Point(72, 71));
    }
}