package appendix_java_8_11.a1_lambdas;

import static java.util.function.Predicate.not;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und 
 * verschiedene "Java 21 LTS -- ..."-Bücher
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class PredicateInActionExample
{
    public static void main(final String[] args)
    {
        var cities = List.of("Kiel", "Köln", "Aachen", "Zürich", "Bern",
                             "", " ", "  ", "Bremen", "Hamburg", "Lübeck");

        var mutableCities = new ArrayList<>(cities);

        Predicate<String> isBlank = String::isBlank;
        Predicate<String> fiveOrMoreChars = str -> str.length() >= 5;

        mutableCities.removeIf(fiveOrMoreChars.negate());
        mutableCities.removeIf(isBlank.or(not(fiveOrMoreChars)));

        System.out.println(mutableCities);
    }
}
