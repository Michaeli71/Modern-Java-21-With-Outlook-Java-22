package appendix_java_8_11.a2_streams;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und 
 * verschiedene "Java 21 LTS -- ..."-Bücher
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class SortedAndDistinctExample
{
    public static void main(final String[] args)
    {
        final Stream<Integer> distinct = createIntStream().distinct();
        final Stream<Integer> sorted = createIntStream().sorted();
        final Stream<Integer> sortedAndDistinct = createIntStream().sorted().distinct();

        printWithHint("distinct:          ", distinct);
        printWithHint("sorted:            ", sorted);
        printWithHint("sortedAndDistinct: ", sortedAndDistinct);
    }

    private static Stream<Integer> createIntStream()
    {
        return Stream.of(7, 1, 4, 3, 7, 2, 6, 5, 7, 9, 8);
    }

    private static void printWithHint(final String hint, final Stream<Integer> stream)
    {
        final List<Integer> result = stream.collect(Collectors.toList());
        System.out.println(hint + result);
    }
}