package appendix_java_8_11.misc;

import java.util.Arrays;
import java.util.List;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und 
 * verschiedene "Java 21 LTS -- ..."-Bücher
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class MethodReferenceIntroExample
{
    public static void main(final String[] args)
    {
        final List<String> names = Arrays.asList("Max", "Andy", "Michael", "Stefan");

        // $\mbox{\bfseries Lambda }$
        names.forEach(it -> System.out.println(it));

        // $\mbox{\bfseries Methodenreferenz }$
        names.forEach(System.out::println);
    }
}
