package appendix_java_8_11.streams;

import static java.util.stream.Collectors.counting;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.joining;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und 
 * verschiedene "Java 21 LTS -- ..."-Bücher
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class CollectorsSpecialExample
{
    public static void main(final String[] args)
    {
        final List<String> names = Arrays.asList("Stefan", "Ralph", "Andi", "Mike",
                                                 "Florian", "Michael", "Sebastian");

        String joined = names.stream().sorted().collect(joining(", "));

        Map<Integer, List<String>> grouped = names.stream().
                        collect(groupingBy(String::length));
        Map<Integer, Long> counting = names.stream().
                        collect(groupingBy(String::length,
                                           counting()));

        System.out.println("joined: " + joined);
        System.out.println("grouped: " + grouped);
        System.out.println("counting: " + counting);
    }
}
