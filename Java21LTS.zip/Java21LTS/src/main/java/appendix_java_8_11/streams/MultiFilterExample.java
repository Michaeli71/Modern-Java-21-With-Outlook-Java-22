package appendix_java_8_11.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und 
 * verschiedene "Java 21 LTS -- ..."-Bücher
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class MultiFilterExample
{
    public static void main(final String[] args)
    {
        final List<Person> persons = new ArrayList<>();
        persons.add(new Person("Micha", 53, "Zürich"));
        persons.add(new Person("Micha", 41, "Aachen"));
        persons.add(new Person("Micha", 30, "Kiel"));
        persons.add(new Person("Micha", 22, "Oldenburg"));
        persons.add(new Person("Micha", 7, "Stuhr"));

        final Stream<Person> allAdultMikes = persons.stream().
                        filter(Person::isAdult).
                        filter(person -> person.getName().equals("Micha")).
                        filter(micha -> micha.livesIn("Zürich") ||
                                        micha.livesIn("Kiel"));

        allAdultMikes.forEach(System.out::println);
    }
}