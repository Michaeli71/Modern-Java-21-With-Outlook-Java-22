package ch10_api_java_18_21.ch10_01_reflection;

import java.lang.invoke.MethodHandles;
import java.util.Arrays;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class ReflectionExample
{
    public static void main(final String[] args) throws ReflectiveOperationException
    {
        accessFieldOldStyle("Java 21 LTS Rocks");
        accessFieldNewStyle("Java 21 LTS Rocks");
    }

    private static void accessFieldOldStyle(final String input) throws ReflectiveOperationException
    {
        var field = String.class.getDeclaredField("value");
        field.setAccessible(true);

        System.out.println(Arrays.toString((byte[]) field.get(input)));
    }

    private static void accessFieldNewStyle(final String input) throws ReflectiveOperationException
    {
        var lookup = MethodHandles.privateLookupIn(String.class,
                                                   MethodHandles.lookup());
        var handle = lookup.findVarHandle(String.class, "value", byte[].class);

        System.out.println(Arrays.toString((byte[]) handle.get(input)));
    }
}