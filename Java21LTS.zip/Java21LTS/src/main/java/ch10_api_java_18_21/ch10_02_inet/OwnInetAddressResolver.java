package ch10_api_java_18_21.ch10_02_inet;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.net.spi.InetAddressResolver;
import java.util.stream.Stream;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class OwnInetAddressResolver implements InetAddressResolver
{
    @Override
    public Stream<InetAddress> lookupByName(String host,
                                            LookupPolicy lookupPolicy)
                    throws UnknownHostException
    {
        if (host.equals("www.dpunkt.de") || host.equals("www.heise.de"))
        {
            var localhost = new byte[] { 127, 0, 0, 1 };
            return Stream.of(InetAddress.getByAddress(localhost));
        }
        throw new UnsupportedOperationException();
    }

    @Override
    public String lookupByAddress(byte[] addr)
    {
        throw new UnsupportedOperationException();
    }
}