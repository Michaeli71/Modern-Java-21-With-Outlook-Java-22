package ch10_api_java_18_21.misc;

import java.util.Locale;
import java.util.stream.Stream;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class LocaleExample
{
    public static void main(final String[] args)
    {
        Stream<Locale> localeStream = Locale.availableLocales();
        System.out.println(localeStream.filter(loc -> loc.getLanguage().equals("de")).limit(7).toList());
    }
}
