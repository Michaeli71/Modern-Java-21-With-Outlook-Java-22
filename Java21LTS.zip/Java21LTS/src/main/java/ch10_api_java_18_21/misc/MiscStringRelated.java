package ch10_api_java_18_21.misc;

import java.util.Arrays;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class MiscStringRelated
{
    public static void main(final String[] args)
    {
        var sb = new StringBuffer();
        sb.repeat('*', 10);
        System.out.println(sb.toString());

        var tomAndJerry = "tom:and::jerry:::news---ticker---top";

        String[] splits = tomAndJerry.splitWithDelimiters(":+", 3);
        System.out.println(Arrays.toString(splits));

        // limit bezieht sich auf die Matches, Delimiter zählen nicht mit
        String[] splits2 = tomAndJerry.splitWithDelimiters("(:+|-{3})", 4);
        System.out.println(Arrays.toString(splits2));

        String[] splits3 = tomAndJerry.splitWithDelimiters("(:+|-{3})", 5);
        System.out.println(Arrays.toString(splits3));

        String[] splits4 = tomAndJerry.splitWithDelimiters("(:+|-{3})", 6);
        System.out.println(Arrays.toString(splits4));
    }
}
