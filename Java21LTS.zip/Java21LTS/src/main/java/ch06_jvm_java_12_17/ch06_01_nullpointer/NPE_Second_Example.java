package ch06_jvm_java_12_17.ch06_01_nullpointer;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021-2025 by Michael Inden
 */
public class NPE_Second_Example
{
    public static void main(final String[] args)
    {
        try
        {
            final String[] stringArray = { null, null, null };
            final int errorPos = stringArray[2].lastIndexOf("ERROR");
        }
        // In der Praxis bitte keine NullPointerException fangen,
        // hier nur damit die folgenden Anweisungen ausgeführt werden
        catch (final NullPointerException e)
        {
            e.printStackTrace();
        }

        try
        {
            final Integer value = null;
            final int sum = value + 3;
        }
        catch (final NullPointerException e)
        {
            e.printStackTrace();
        }
    }
}