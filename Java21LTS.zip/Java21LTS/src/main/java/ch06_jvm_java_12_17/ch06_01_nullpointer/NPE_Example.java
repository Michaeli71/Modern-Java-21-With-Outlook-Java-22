package ch06_jvm_java_12_17.ch06_01_nullpointer;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021-2025 by Michael Inden
 */
public class NPE_Example
{
    class A
    {
        String value;
    }

    public static void main(final String[] args)
    {
        A a = null;
        a.value = "ERROR";
    }
}