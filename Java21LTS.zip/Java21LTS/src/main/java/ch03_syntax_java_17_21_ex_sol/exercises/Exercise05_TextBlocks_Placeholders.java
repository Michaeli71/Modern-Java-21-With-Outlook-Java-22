package ch03_syntax_java_17_21_ex_sol.exercises;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021-2025 by Michael Inden
 */
public class Exercise05_TextBlocks_Placeholders
{
    public static void main(final String[] args)
    {
        String multiLineStringWithPlaceHoldersOld = String.format("HELLO \"%s\"!\n" +
                                                                                  "  HAVE %s\n" +
                                                                                  "  NICE \"%s\"!",
                                                                  "WORLD", "A", "DAY");
        System.out.println(multiLineStringWithPlaceHoldersOld);

        String multiLineStringWithPlaceHolders = null; // TODO
        System.out.println(multiLineStringWithPlaceHolders);
    }
}
