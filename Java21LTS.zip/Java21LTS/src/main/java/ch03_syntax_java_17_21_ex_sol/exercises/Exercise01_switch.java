package ch03_syntax_java_17_21_ex_sol.exercises;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021-2025 by Michael Inden
 */
public class Exercise01_switch
{
    public static void main(String[] args)
    {
        evaluateOld(7);
        evaluateOld(10);

        System.out.println("Bonus A: " + switchBonusOld('A'));
        System.out.println("Bonus C: " + switchBonusOld('C'));
        System.out.println("Bonus E: " + switchBonusOld('E'));
    }

    private static void evaluateOld(final int number)
    {
        switch (number)
        {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                System.out.println("Durchgefallen");
                break;
            case 6:
            case 7:
            case 8:
                System.out.println("Gut");
                break;
            case 9:
            case 10:
                System.out.println("Exzellent");
                break;
            default:
                System.out.println("Ungültig");
                break;
        }
    }

    private static int switchBonusOld(final char grade)
    {
        int bonus;
        switch (grade)
        {
            case 'A':
                bonus = 2000;
                break;
            case 'B':
                bonus = 1000;
                break;
            case 'C':
                bonus = 500;
                break;
            default:
                bonus = 0;
                break;
        }

        return bonus;
    }
}
