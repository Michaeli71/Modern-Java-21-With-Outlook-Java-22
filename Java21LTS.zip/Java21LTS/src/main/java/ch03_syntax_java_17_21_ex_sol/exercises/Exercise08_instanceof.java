package ch03_syntax_java_17_21_ex_sol.exercises;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021-2025 by Michael Inden
 */
public class Exercise08_instanceof
{
    public static void main(String[] args)
    {
        Object obj = "BITTE MICHAEL";

        if (obj instanceof String)
        {
            final String str = (String) obj;
            if (str.contains("BITTE"))
            {
                System.out.println("It contains the magic word!");
            }
        }
    }
}
