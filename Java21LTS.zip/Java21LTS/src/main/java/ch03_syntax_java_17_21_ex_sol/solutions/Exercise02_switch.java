package ch03_syntax_java_17_21_ex_sol.solutions;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021-2025 by Michael Inden
 */
public class Exercise02_switch
{
    public static void main(String[] args)
    {
        int value = 6;

        dumbEvenOddChecker2a(value);

        String result1 = dumbEvenOddChecker2b(value);
        System.out.println("result1: " + result1);

        String result2 = dumbEvenOddChecker2cSpecialCase(value);
        System.out.println("result2: " + result2);
    }

    private static void dumbEvenOddChecker2a(int value)
    {
        String result;

        switch (value)
        {
            case 1, 3, 5, 7, 9 -> result = "odd";
            case 0, 2, 4, 6, 8 -> result = "even";
            default -> result = "only implemented for values from 0 to 9";
        }

        System.out.println("result: " + result);
    }

    private static String dumbEvenOddChecker2b(int value)
    {
        return switch (value)
        {
            case 1, 3, 5, 7, 9 -> "odd";
            case 0, 2, 4, 6, 8 -> "even";
            default -> "only implemented for values from 0 to 9";
        };
    }

    private static String dumbEvenOddChecker2cSpecialCase(int value)
    {
        return switch (value)
        {
            case 1, 3, 5, 7, 9 -> "odd";
            case 0, 2, 4, 6, 8 ->
            {
                if (value > 1 && value < 9)
                    System.out.println("Hurra, es ist gerade und im Bereich 2 -- 8");

                yield "even";
            }
            default -> "only implemented for values from 0 to 9";
        };
    }
}
