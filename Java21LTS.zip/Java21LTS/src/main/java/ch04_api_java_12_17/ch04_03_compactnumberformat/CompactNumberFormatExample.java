package ch04_api_java_12_17.ch04_03_compactnumberformat;

import java.text.NumberFormat;
import java.util.Locale;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021-2025 by Michael Inden
 */
public class CompactNumberFormatExample
{
    public static void main(final String args[])
    {
        var shortFormat = getUsCompactNumberFormat(NumberFormat.Style.SHORT);
        formatNumbers("SHORT", shortFormat);

        var longFormat = getUsCompactNumberFormat(NumberFormat.Style.LONG);
        formatNumbers("LONG", longFormat);
    }

    private static NumberFormat getUsCompactNumberFormat(NumberFormat.Style style)
    {
        return NumberFormat.getCompactNumberInstance(Locale.US, style);
    }

    private static void formatNumbers(final String style, final NumberFormat numberFormat)
    {
        System.out.println("\nNumberFormat " + style);
        System.out.println("Result: " + numberFormat.format(10_000));
        System.out.println("Result: " + numberFormat.format(123_456));
        System.out.println("Result: " + numberFormat.format(1_234_567));
        System.out.println("Result: " + numberFormat.format(1_950_000_000));
    }

}
