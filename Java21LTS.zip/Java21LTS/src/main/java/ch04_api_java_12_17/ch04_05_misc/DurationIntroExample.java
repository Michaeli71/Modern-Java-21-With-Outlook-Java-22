package ch04_api_java_12_17.ch04_05_misc;

import java.time.Duration;
import java.time.temporal.ChronoUnit;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021-2025 by Michael Inden
 */
public class DurationIntroExample
{
    public static void main(final String[] args)
    {
        System.out.println(Duration.of(20L, ChronoUnit.DAYS).isNegative());
        System.out.println(Duration.of(-12L, ChronoUnit.DAYS).isNegative());
    }
}