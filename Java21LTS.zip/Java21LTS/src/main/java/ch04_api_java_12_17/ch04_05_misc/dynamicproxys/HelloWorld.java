package ch04_api_java_12_17.ch04_05_misc.dynamicproxys;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021-2025 by Michael Inden
 */
interface HelloWorld
{
    default String hello()
    {
        return "world";
    }
}