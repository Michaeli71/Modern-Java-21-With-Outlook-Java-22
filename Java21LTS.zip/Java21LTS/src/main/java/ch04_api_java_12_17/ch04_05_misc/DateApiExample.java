package ch04_api_java_12_17.ch04_05_misc;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021-2025 by Michael Inden
 */
public class DateApiExample
{
    public static void main(String[] args)
    {
        var localTime = LocalTime.parse("15:25:08.690791");
        var formatter = DateTimeFormatter.ofPattern("h B");

        System.out.println(localTime.format(formatter));
    }
}
