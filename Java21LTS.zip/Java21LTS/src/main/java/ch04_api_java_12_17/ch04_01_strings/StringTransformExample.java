package ch04_api_java_12_17.ch04_01_strings;

import java.util.Arrays;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021-2025 by Michael Inden
 */
public class StringTransformExample
{
    public static void main(final String[] args)
    {
        transformationOldStyle();
        transformationJdk12Style();
    }

    private static void transformationOldStyle()
    {
        var text = "This is a Test";

        var upperCase = text.toUpperCase();
        var withoutTs = upperCase.replaceAll("T", "");
        var result = withoutTs.split(" ");

        System.out.println(Arrays.toString(result));
    }

    private static void transformationJdk12Style()
    {
        var text = "This is a Test";

        // Hintereinanderschaltung von Operationen
        var result = text.transform(String::toUpperCase).transform(str -> str.replaceAll("T", ""))
                        .transform(str -> str.split(" "));

        System.out.println(Arrays.toString(result));
    }
}
