package ch06_api_java_12_17_ex_sol.exercises;

import java.util.Arrays;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021-2025 by Michael Inden
 */
public class Exercise02_String_Transform
{
    public static void main(String[] args)
    {

        var csvText = "HELLO,WORKSHOP,PARTICIPANTS,!,LET'S,HAVE,FUN";

        // Aufgabe 2a
        var allLowerCaseNoCommas = csvText.transform(String::toLowerCase)
                        .transform(str -> str.replace(",", " "));
        System.out.println(allLowerCaseNoCommas);

        // Aufgabe 2b
        var asSingleValues = csvText.transform(str -> str.replace("HELLO", "GRÜEZI"))
                        .transform(str -> str.split(","));
        System.out.println(Arrays.asList(asSingleValues));
    }
}
