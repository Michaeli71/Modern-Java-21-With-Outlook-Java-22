package ch06_api_java_12_17_ex_sol.exercises;

import java.util.List;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021-2025 by Michael Inden
 */
public class Exercise03_CompactNumberFormat
{
    public static void main(final String args[])
    {
        List<Integer> allValues = List.of(1_000, 1_000_000, 1_000_000_000);
        List<String> germanParseInputs = List.of("13\u00a0KILO", "1\u00a0Mio.", "1\u00a0Mrd.");
        List<String> italianParseInputs = List.of("1 mille", "1 milione");

        // TODO
    }
}
