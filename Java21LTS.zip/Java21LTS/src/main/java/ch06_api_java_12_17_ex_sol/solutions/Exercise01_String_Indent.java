package ch06_api_java_12_17_ex_sol.solutions;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 * und verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021-2025 by Michael Inden
 */
public class Exercise01_String_Indent
{
    public static void main(String[] args)
    {
        var originalString = "first_line\nsecond_line\nlast_line";

        // 1a
        System.out.println(originalString);
        System.out.println("-- indented string --");

        var indentedString = originalString.indent(7);
        System.out.println(indentedString);

        System.out.println("-- corrected indented string --");
        var correctedIndentedString = indentedString.indent(-3);
        System.out.println(correctedIndentedString);

        // 1b
        var multiLineIndentedString = "LINE 1\n    LINE 2" +
                        "\n            LINE 3\n     LINE 4";
        System.out.println(multiLineIndentedString);

        System.out.println("-- negatively indented string --");
        var result = multiLineIndentedString.indent(-10);
        System.out.println(result);
    }
}
