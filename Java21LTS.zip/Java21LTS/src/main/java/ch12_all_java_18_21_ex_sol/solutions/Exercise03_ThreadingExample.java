package ch12_all_java_18_21_ex_sol.solutions;

import java.time.Duration;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;

/**
 * Beispielprogramm für die Workshops "Best of Java" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19" und
 * verschiedene "Java 21 LTS -- ..."-Bücher
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021-2025 by Michael Inden
 */
public class Exercise03_ThreadingExample
{
    public static void main(String[] args)
    {
        try (var executor = Executors.newVirtualThreadPerTaskExecutor())
        {
            IntStream.range(0, 10_000).forEach(i -> {
                executor.submit(() -> {
                    Thread.sleep(Duration.ofSeconds(5));

                    boolean isVirtual = Thread.currentThread().isVirtual();
                    System.out.println("Task " + i + " finished! virtual = " + isVirtual);
                    return i;
                });
            });
        }

        System.out.println("FINISHED");
    }
}
